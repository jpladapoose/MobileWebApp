# Apache Cordova for BlackBerry
===

This repo contains cordova projects for the BlackBerry platforms:

blackberry - BBOS 5+ and Tablet OS

blackberry10 - BB10

Please see README files in the sub folders for more information.
